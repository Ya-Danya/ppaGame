package com.example.paperfx.client;

import javafx.application.Application;

public final class ClientMain {
    public static void main(String[] args) {
        Application.launch(PaperFxApp.class, args);
    }
}
